import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import {DataTableModule} from "angular-6-datatable";
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { InsertComponent } from './insert/insert.component';
import {MatDialogModule} from '@angular/material/dialog';
import { UploadComponent } from './upload/upload.component';
import * as XLSX  from 'xlsx';
import { UploadService } from './upload.service';
import { ManagerComponent } from './manager/manager.component';
import { StockmanComponent } from './stockman/stockman.component';
import { OrderlistComponent } from './orderlist/orderlist.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    ManagerComponent,
    StockmanComponent,
    DashboardComponent,
    InsertComponent,
    UploadComponent,
    OrderlistComponent,
    SignupComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    DataTableModule,
    HttpClientModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    LayoutModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path:'insert',component:InsertComponent},
      {path:'signup',component:SignupComponent},
      {path:'login',component:LoginComponent},
      {path:'login/login',component:LoginComponent},
      {path:'login/signup',component:SignupComponent},
      
      {path:'',component:LoginComponent},
      {path:'orderlist',component:OrderlistComponent},
      {path:'upload',component:UploadComponent},
      {path:'stock',component:StockmanComponent},
      {path:'manager',component:ManagerComponent},
    ]),
    BrowserAnimationsModule,
    NgbModule,
  ],
  providers: [UploadService],
  bootstrap: [AppComponent]
})
export class AppModule { }
