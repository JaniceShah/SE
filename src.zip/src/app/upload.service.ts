import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UploadService {
  
  constructor(private http:HttpClient) { }

  PostFoodList(add){
   this.http.post('http://localhost/inventory/insertfile.php',add).toPromise().then(
    data => {
        console.log('POST Request is successful ', data);
    },
    error => {
        console.log('Error', error);
    });
  }

  login(user){
    return this.http.post('http://localhost/inventory/login.php',user).toPromise().then(
      data => {
          console.log('POST Request is successful ', data);
          return data;
      },
      error => {
          console.log('Error', error);
          return false;
        });
  }

  PostOrder(name){
  return this.http.post('http://localhost/inventory/insertorder.php',name).toPromise().then(
    data => {
        console.log('POST Request is successful ', data);
        return data;
    },
    error => {
        console.log('Error', error);
        return false;
      });
    
  }

  Register(user){
    this.http.post('http://localhost/inventory/register.php',user).toPromise().then(
      data => {
          console.log('POST Request is successful ', data);
      },
      error => {
          console.log('Error', error);
      });
  }

  PostStockDataFile(add){
    this.http.post('http://localhost/inventory/insertfile.php',add).toPromise().then(
      data => {
          console.log('POST Request is successful ', data);
      },
      error => {
          console.log('Error', error);
      });
    }
    
  DeleteOrder(id){
      console.log(id);
      this.http.post('http://localhost/inventory/delete.php',id).toPromise().then(
      data => {
          console.log('POST Request is successful ', data);
      },
      error => {
          console.log('');
      });
    }
  }
